import yaml
import os

def load_config(file_path="config/config.yaml"):
    if not os.path.exists(file_path) and os.path.exists(os.path.basename(file_path)):
        file_path = os.path.basename(file_path)
    with open(file_path, "r") as f:
        return yaml.safe_load(f)
