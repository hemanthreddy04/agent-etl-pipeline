import os
import requests
import json

def publish_alert(severity, payload, project_id):
    print(f"[{severity}] ALERT for Project {project_id}: {payload}")
    
    slack_webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
    if not slack_webhook_url:
        print("Warning: SLACK_WEBHOOK_URL not set. Skipping Slack alert.")
        return

    # Format the message for Slack
    message_text = f"*{severity} ALERT* (Project: {project_id})\n"
    for k, v in payload.items():
        message_text += f"• *{k}*: {v}\n"

    slack_data = {"text": message_text}
    
    try:
        response = requests.post(
            slack_webhook_url, 
            data=json.dumps(slack_data),
            headers={'Content-Type': 'application/json'}
        )
        if response.status_code != 200:
            print(f"Failed to send Slack alert. Status Code: {response.status_code}")
    except Exception as e:
        print(f"Error sending Slack alert: {e}")
