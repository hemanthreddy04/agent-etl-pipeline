import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, max as spark_max
from pyspark.sql.types import StringType
from google.cloud import bigquery
from src.utils.config_loader import load_config
from src.readers.file_reader import read_source_data
from src.utils.alert import publish_alert

def process_bronze():
    # 1. Initialize Spark & BQ
    spark = SparkSession.builder \
        .appName("SourceToBronze_Ingestion") \
        .getOrCreate()
    bq_client = bigquery.Client()
    
    # 2. Load Config
    config = load_config()
    project_id = config['project_id']
    
    # 3. Process Each Table
    for table in config['source']['tables']:
        table_name = table['name']
        target_dataset_id = table['target_dataset_id']
        target_bq_table = f"{project_id}.{target_dataset_id}.{table['target_table_name']}"
        gcs_backup_path = f"gs://{config['gcs_backup_bucket']}/{project_id}/backup/{table_name}/"
        
        # Ensure target dataset exists
        dataset_ref = bigquery.Dataset(f"{project_id}.{target_dataset_id}")
        bq_client.create_dataset(dataset_ref, exists_ok=True)
        
        watermark_col = table.get('watermark_column')
        required_columns = table.get('required_columns', [])
        stop_pipeline = False
        
        # A. READ SOURCE
        raw_df = read_source_data(spark, table, project_id)
        
        # B. INCREMENTAL FILTERING
        incremental_df = raw_df
        if watermark_col:
            try:
                backup_df = spark.read.parquet(gcs_backup_path)
                max_wm = backup_df.agg(spark_max(col(watermark_col)).alias("max_wm")).collect()[0]["max_wm"]
                if max_wm:
                    incremental_df = raw_df.filter(col(watermark_col) > lit(max_wm))
            except Exception as e:
                print(f"No existing backup found for {table_name}. Doing full load.")
                
        if incremental_df.count() == 0:
            continue
            
        # C. SCHEMA VALIDATION & EVOLUTION
        incoming_columns = set(incremental_df.columns)
        
        # 1. Missing Required Columns (All expected columns are required)
        missing_req = [c for c in required_columns if c not in incoming_columns]
        if missing_req:
            publish_alert("HIGH", {"table": table_name, "missing": missing_req}, project_id)
            for c in missing_req: 
                incremental_df = incremental_df.withColumn(c, lit(None).cast(StringType()))
            stop_pipeline = True
            
        # 2. Check for Extra Columns and Data Type Mismatches (Schema Evolution)
        try:
            bq_table = bq_client.get_table(target_bq_table)
            bq_columns = {field.name: field.field_type for field in bq_table.schema}
            
            # A. Extra Columns
            extra_cols = [c for c in incoming_columns if c not in bq_columns]
            if extra_cols:
                publish_alert("WARNING", {"table": table_name, "new_columns": extra_cols}, project_id)
                
            # B. Data Type Mismatches
            incoming_dtypes = dict(incremental_df.dtypes)
            for bq_col_name, bq_col_type in bq_columns.items():
                if bq_col_name in incoming_dtypes:
                    incoming_type = incoming_dtypes[bq_col_name].upper()
                    
                    # BigQuery rejects changing from numeric/boolean to STRING via normal schema evolution.
                    # We drop the column so it gets cleanly re-created with the new type by PySpark.
                    if bq_col_type in ['INTEGER', 'INT64', 'FLOAT', 'FLOAT64', 'BOOLEAN'] and 'STRING' in incoming_type:
                        publish_alert("WARNING", {"table": table_name, "type_changed_to_string": bq_col_name}, project_id)
                        drop_sql = f"ALTER TABLE `{target_bq_table}` DROP COLUMN {bq_col_name}"
                        bq_client.query(drop_sql).result()
                        
        except Exception:
            pass # Table does not exist yet

        # D. UNIVERSAL GCS BACKUP
        incremental_df.write.mode("append").format("parquet").save(gcs_backup_path)
            
        if stop_pipeline:
            continue # Skip Bronze load
            
        # E. TRUNCATE & LOAD BRONZE BQ
        incremental_df.write \
            .format("bigquery") \
            .option("table", target_bq_table) \
            .option("writeMethod", "direct") \
            .mode("overwrite") \
            .option("schemaUpdateOptions", "ALLOW_FIELD_ADDITION,ALLOW_FIELD_RELAXATION") \
            .save()

if __name__ == "__main__":
    process_bronze()
