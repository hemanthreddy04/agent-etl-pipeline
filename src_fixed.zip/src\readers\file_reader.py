from pyspark.sql import SparkSession

def read_source_data(spark: SparkSession, table_config: dict, project_id: str = None):
    """
    Reads data based on the format specified in the config.
    """
    file_format = table_config.get('format', '').lower()
    
    if file_format in ['bigquery', 'table']:
        dataset_id = table_config.get('dataset_id')
        table_name = table_config.get('table_name')
        fq_table = f"{project_id}.{dataset_id}.{table_name}" if project_id else f"{dataset_id}.{table_name}"
        return spark.read.format("bigquery").option("table", fq_table).load()
        
    # Handle GCS sources
    source_path = table_config.get('source_path')
    if not source_path and 'bucket_name' in table_config:
        source_path = f"gs://{table_config['bucket_name']}/{table_config.get('path', '')}"

    if file_format == 'csv':
        return spark.read.csv(source_path, header=True, inferSchema=True)
    elif file_format in ['json', 'jsonl']:
        return spark.read.json(source_path)
    elif file_format == 'parquet':
        return spark.read.parquet(source_path)
    else:
        raise ValueError(f"Unsupported format: {file_format}")
